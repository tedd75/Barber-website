CREATE SCHEMA IF NOT EXISTS `tin-example-sequelize`;
